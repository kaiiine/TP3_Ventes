/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp3ventes;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author quent
 */
public class TP3Ventes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
                List<Equipement> equipement=new ArrayList<>();
                List<LigneCommande> commande=new ArrayList<>();
                
                
                Magasin magasin = new Magasin(equipement,commande);
                magasin.ajout("Basketball","ballon",34,143,3,24.8,24.8);
                magasin.ajout("Football","protege-tibias",123,30,"M","Black","expert");
                magasin.ajout("Football","Short",123,30,"S","White");
                magasin.ajout("Football","Short",123,30,"M","White");
                magasin.ajout("Football","t-shirt",123,30,"XL","White");
                //System.out.println(magasin.recherche("JO001"));              
                magasin.choixEquip();
                for(int i=0;i<magasin.commande.size();i++){
                    System.out.println(magasin.commande.get(i));
                }
                

	}
    
}
