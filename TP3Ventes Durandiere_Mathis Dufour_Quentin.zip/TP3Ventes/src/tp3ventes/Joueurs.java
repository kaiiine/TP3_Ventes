package tp3ventes;

public class Joueurs extends Equipement{

	private String taille;
        private String coloris;
	
	public Joueurs(String ref, String sport, String designation, double prix, int nbrExemplaires, String taille, String coloris) {
		super(ref,sport,designation,prix,nbrExemplaires);
                this.taille=taille;
                this.coloris=coloris;
	}
	
        public String toString() {
         
        return super.toString()+
                "\nTaille : "+this.taille+
                "\nColoris : "+this.coloris; 
        
    }
}
