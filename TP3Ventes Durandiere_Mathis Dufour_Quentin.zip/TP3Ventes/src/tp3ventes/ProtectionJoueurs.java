package tp3ventes;

public class ProtectionJoueurs extends Joueurs{

    private String niveau;
    
	public ProtectionJoueurs(String ref, String sport, String designation, double prix, int nbrExemplaires, String taille, String coloris,String niveau) {
            super(ref,sport,designation,prix,nbrExemplaires,taille,coloris);
            this.niveau=niveau;
		
	}
        
        public String toString() {
            
        return super.toString()+
               "\nNiveau : "+this.niveau; 
        
    }
}