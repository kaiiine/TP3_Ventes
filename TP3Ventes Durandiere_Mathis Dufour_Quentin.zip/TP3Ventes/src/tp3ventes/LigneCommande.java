package tp3ventes;

public class LigneCommande {

    private String referenceCommande;
    private int nbrExemplaires;
    private double prix;

    LigneCommande(String reference, int nbrExemplaires, double prix) {
        
        this.referenceCommande = reference ;
        this.nbrExemplaires = nbrExemplaires ;
        this.prix = prix ;
        
    }
    
    public String toString() {
        
        return referenceCommande + ", " + nbrExemplaires + ", " + prix ; 
        
    }
}
