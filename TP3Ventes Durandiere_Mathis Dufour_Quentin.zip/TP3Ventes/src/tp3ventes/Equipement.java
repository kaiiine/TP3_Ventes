    package tp3ventes;

public class Equipement {

	private String reference;
	private String sport;
	private String designation;
	private double prix;
	private int nbrExemplaires;
	
	public Equipement(String ref, String sport, String designation, double prix, int nbrExemplaires) {
            
            this.reference=ref;
            this.sport=sport;
            this.designation=designation;
            this.prix=prix;
            this.nbrExemplaires=nbrExemplaires;
	}
	
	public String toString() {
            return "\nVoici les informations de votre objet : "+this.designation+"\n"+
                    "\nReference : "+this.reference+
                    "\nSport : "+this.sport+
                    "\nDesignation : "+this.designation+
                    "\nPrix : "+this.prix+
                    "\nNombre d'exemplaires : "+this.nbrExemplaires;
	}
        
        public boolean placeApres(Equipement objet) {
            boolean change =false;
            for(int i=0; i<this.reference.length();i++){
                if(this.reference.charAt(i)>objet.reference.charAt(i)){
                    change=true;
                    break;
                }
                
            }
            if(change==true){
                    return true;
                }else{
                    return false;
                }
           
        }
        
        public String getReference(){
            return this.reference;
        }
        
        public String getSport(){
            return this.sport;
        }
        
        public int getNbrExemplaires(){
            return this.nbrExemplaires;
        }
        
        public double getPrix(){
            return this.prix;
        }
}
