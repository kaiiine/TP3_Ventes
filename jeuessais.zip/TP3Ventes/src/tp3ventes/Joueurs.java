package tp3ventes;

public class Joueurs extends Equipement{

	private String taille;
        private String coloris;
	
	public Joueurs(String ref, String sport, String designation, double prix, int nbrExemplaires, String taille, String coloris) {
		super(ref,sport,designation,prix,nbrExemplaires);
                this.taille=taille;
                this.coloris=coloris;
	}
	
        public String toString() {
         
        return super.toString()+
                "\nTaille : "+this.taille+
                "\nColoris : "+this.coloris; 
        
    }
        
        public String versFichier(){
            return super.versFichier() + " : " + this.taille + " : " + this.coloris;    /* Retourne une chaine de caractère contenant la référence, un retour à la ligne,
                                                                                           les attributs de la classe mère + ceux de la classe Joueurs, tous séparés par " : "  */
        }

        
    public String getTaille(){
        return this.taille;
    }    
    
    public String getColoris(){
        return this.coloris;
    }
        
    public double getPoids() {
        return 0;
    }

    public double getHauteur() {
        return 0;
    }

    public double getLargeur() {
        return 0;
    }

    public String getNiveau() {
        return "";
    }



}
