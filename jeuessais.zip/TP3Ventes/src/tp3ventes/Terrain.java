package tp3ventes;

public class Terrain extends Equipement{

	private double poids;
	private double hauteur;
	private double largeur;
	
	public Terrain(String ref, String sport, String designation, double prix, int nbrExemplaires, double poids, double hauteur, double largeur) {
		super(ref,sport,designation, prix, nbrExemplaires);     // Initialise les attributs de la classe Equipement
                this.poids=poids;                                       //Initialisation des attributs de la classe Terrain
                this.hauteur=hauteur;
                this.largeur=largeur;
	}
        
        public Terrain(String ref, String sport, String designation, double prix, int nbrExemplaires,double poids){
            super(ref,sport,designation, prix, nbrExemplaires);
            this.poids=poids;
        }
        
        public String toString() {
        
        return super.toString()+
            "\nPoids : "+this.poids+
            "\n Hauteur : "+this.hauteur+
            "\nLargeur : "+this.largeur; 
        
        }
        
        public String versFichier(){
            return super.versFichier() + " : " + this.poids + " : " + this.hauteur + " : " + this.largeur;  /* Retourne une chaine de caractère contenant la référence, un retour à la ligne,
                                                                                                               les attributs de la classe mère + ceux de la classe Terrain, tous séparés par " : "  */
        }
        
        public double getPoids(){
            return this.poids;
        }
        
        public double getHauteur(){
            return this.hauteur;
        }
        
        public double getLargeur(){
            return this.largeur;
        }


    public String getTaille() {
        throw new UnsupportedOperationException("Not supported yet.");
    }


    public String getColoris() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }


    public String getNiveau() {
        throw new UnsupportedOperationException("Not supported yet.");
    }


}
