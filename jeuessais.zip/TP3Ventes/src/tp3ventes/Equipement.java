    package tp3ventes;

public abstract class Equipement {

	private String reference;
	private String sport;
	private String designation;
	private double prix;
	private int nbrExemplaires;
	
	public Equipement(String ref, String sport, String designation, double prix, int nbrExemplaires) {
            
            this.reference=ref;
            this.sport=sport;
            this.designation=designation;
            this.prix=prix;
            this.nbrExemplaires=nbrExemplaires;
            
            //double poids = getPoids();
	}
	
	public String toString() {
            return "\nVoici les informations de votre objet : "+this.designation+"\n"+
                    "\nReference : "+this.reference+
                    "\nSport : "+this.sport+
                    "\nDesignation : "+this.designation+
                    "\nPrix : "+this.prix+
                    "\nNombre d'exemplaires : "+this.nbrExemplaires;
	}
        
        public boolean placeApres(Equipement objet) {
            boolean change_nom =false;
            boolean change_num =false;
            String nom1=this.reference.substring(0,2);
            String nom2=objet.reference.substring(0,2);
            
            if(!nom1.equals(nom2)){ // Si la référence de l'objet appelant est différent de celui appelé et que ses lettres se situent après de celles de l'objet appelé, alors le booléen egale à true 
                if(nom1.charAt(0)>nom2.charAt(0)){
                    change_nom=true;
                }
            }else{  // Si les références des deux objets sont les mêmes, alors on les trie selon leur numéro par ordre croissant
                for(int i=0; i<this.reference.length();i++){
                    if(this.reference.charAt(i)>objet.reference.charAt(i)){
                        change_num=true;
                        break;
                    }
                }
            }
            
            if(change_nom==true || change_num==true){
                    return true;
                }else{
                    return false;
                }
           
        }
        
        public String getReference(){
            return this.reference;
        }
        
        public String getSport(){
            return this.sport;
        }
        
        public int getNbrExemplaires(){
            return this.nbrExemplaires;
        }
        
        public void setNbrExemplaires(){
            this.nbrExemplaires+=1;
        }
        
        public double getPrix(){
            return this.prix;
        }
        
        public String getDesignation(){
            return this.designation;
        }
        
        public abstract String getTaille();
        public abstract String getColoris();
        public abstract String getNiveau();
        public abstract double getPoids();
        public abstract double getHauteur();
        public abstract double getLargeur();
        
        public String versFichier(){
            return getReference() + System.lineSeparator()+sport+" : "+designation+" : "+prix+" : "+nbrExemplaires;  /* Retourne une chaine de caractère contenant la référence, un retour à la ligne,
                                                                                                                        puis les attributs de la classe mère tous séparés par " : "  */
        }
        
        
        public void majDispo(int x) {
            nbrExemplaires += x ;            
        }
       
        public boolean verifDispo (int x) {
            return nbrExemplaires > x ;     //Retourne true si le nombre d'exemplaires en stock dans le magasin est supérieur à la quantité demandé et false sinon
        }

        
        public int calculDelai(int nombre) {
            int delaiMax =3;
            if(this.getPoids()*nombre>100){
                delaiMax=5;
            }
            if(!verifDispo(nombre)){
                delaiMax+=5;
            }
            
            return delaiMax;
        }
        
}
