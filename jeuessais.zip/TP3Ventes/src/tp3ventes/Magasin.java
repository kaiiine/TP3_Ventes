/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp3ventes;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author quent
 */
public class Magasin {

    private final String nomMagasin = "Milieu Sport ou le Rinté";
    public List<Equipement> equipements;
    private int nbrEquipement=0;
    public List<Commande> commandes;
    private int nbrCommandes=0;
    private int cptCommande=0;
    static final String NOM_FICHIER_EQUIPEMENT = "Equipements.txt";
    static final String NOM_FICHIER_COMMANDE = "Commandes.txt";
    private int annee = 2023;

    public Magasin() {
        this.equipements = new ArrayList<>();    //Initialisation du tableau dynamique equipement
        this.commandes = new ArrayList<>();      //Initialisation du tableau dynamique commande
    }

    public void afficherEquipement() {
        for (int i = 0; i < equipements.size(); i++) {
            System.out.println(equipements.get(i));
        }
    }
    
    public void afficherCommande() {
        for (int i = 0; i < commandes.size(); i++) {
            System.out.println(commandes.get(i));
        }
    }

    public Equipement ajout(String sport, String designation, double prix, int nbrExemplaires,double poids) {    //Méthode permettant de créer et de retourner un objet Terrain
        
        for(int i=0;i<this.equipements.size();i++){ //  Boucle for afin de vérifier qu'un objet n'existe pas déjà
            if(this.equipements.get(i).getClass().getSimpleName().equals("Terrain") && this.equipements.get(i).getDesignation().equals(designation) && this.equipements.get(i).getPrix()==prix && this.equipements.get(i).getPoids()==poids){ //Vérifie si équipement n'existe pas déjà
                this.equipements.get(i).setNbrExemplaires();    //Rajoute +1 au nombre d'exemplaires de l'objet existant
                return this.equipements.get(i);
            }
        }
       
        Terrain terrain = new Terrain(genererReference("TR"), sport, designation, prix, nbrExemplaires,poids);
        this.equipements.add(terrain);
        sortEquipement();
        this.nbrEquipement += 1;
        return terrain;
    }

    public Equipement ajout(String sport, String designation, double prix, int nbrExemplaires, double poids, double hauteur, double largeur) {    //Méthode permettant de créer et de retourner un objet Terrain

        for(int i=0;i<this.equipements.size();i++){ //  Boucle for afin de vérifier qu'un objet n'existe pas déjà
            if(this.equipements.get(i).getClass().getSimpleName().equals("Terrain") && this.equipements.get(i).getDesignation().equals(designation) && this.equipements.get(i).getPrix()==prix &&  this.equipements.get(i).getPoids()==poids && this.equipements.get(i).getNbrExemplaires()==nbrExemplaires && this.equipements.get(i).getPoids()==poids && this.equipements.get(i).getHauteur()==hauteur && this.equipements.get(i).getLargeur()==largeur){ //Vérifie si équipement n'existe pas déjà
                this.equipements.get(i).setNbrExemplaires();    //Rajoute +1 au nombre d'exemplaires de l'objet existant
                return this.equipements.get(i);
            }
        }
        
        Terrain terrain = new Terrain(genererReference("TR"), sport, designation, prix, nbrExemplaires, poids, hauteur, largeur);
        this.equipements.add(terrain);
        sortEquipement();
        this.nbrEquipement += 1;
        return terrain;
    }

    public Equipement ajout(String sport, String designation, double prix, int nbrExemplaires, String taille, String coloris) {   //Méthode permettant de créer et de retourner un objet Joueurs
        for(int i=0;i<this.equipements.size();i++){ //  Boucle for afin de vérifier qu'un objet n'existe pas déjà
            if(this.equipements.get(i).getClass().getSimpleName().equals("Joueurs") && this.equipements.get(i).getDesignation().equals(designation) && this.equipements.get(i).getPrix()==prix && this.equipements.get(i).getTaille().equals(taille) && this.equipements.get(i).getColoris().equals(coloris)){ //Vérifie si équipement n'existe pas déjà
                this.equipements.get(i).setNbrExemplaires();    //Rajoute +1 au nombre d'exemplaires de l'objet existant
                return this.equipements.get(i);
            }
        }
        
        Joueurs joueur = new Joueurs(genererReference("JO"), sport, designation, prix, nbrExemplaires, taille, coloris) {};
        this.equipements.add(joueur);
        sortEquipement();
        this.nbrEquipement += 1;
        return joueur;
    }

    public Equipement ajout(String sport, String designation, double prix, int nbrExemplaires, String taille, String coloris, String niveau) { //Méthode permettant de créer et de retourner un objet ProtectionJoueurs
        for(int i=0;i<this.equipements.size();i++){ //  Boucle for afin de vérifier qu'un objet n'existe pas déjà
            if(this.equipements.get(i).getClass().getSimpleName().equals("ProtectionJoueurs") && this.equipements.get(i).getDesignation().equals(designation) && this.equipements.get(i).getPrix()==prix && this.equipements.get(i).getTaille().equals(taille) && this.equipements.get(i).getColoris().equals(coloris) && this.equipements.get(i).getNiveau().equals(niveau)){ //Vérifie si équipement n'existe pas déjà
                this.equipements.get(i).setNbrExemplaires();    //Rajoute +1 au nombre d'exemplaires de l'objet existant
                return this.equipements.get(i);
            }
        }
        
        ProtectionJoueurs protection = new ProtectionJoueurs(genererReference("PR"), sport, designation, prix, nbrExemplaires, taille, coloris, niveau);
        this.equipements.add(protection);
        sortEquipement();
        this.nbrEquipement += 1;
        return protection;
    }
    
    public void ajout(List<LigneCommande> panier){
        Scanner sc = new Scanner(System.in);
        String email;
        int delaiLivraison=3;   // On intialise le délai de livraison par la livraison standart, soit de 3jours
        LocalDate dateLivraison;
        LocalDate dateEmission = LocalDate.now();
        
        for(int i=0;i<panier.size();i++){
            Equipement objet = recherche(panier.get(i).getReferenceCommande()); // Récupère l'objet de la première ligne de commande grâce à la recherche par référence
            if(objet!=null){
                if(objet.calculDelai(panier.get(i).getNbrExemplaires())>delaiLivraison){    // On calcul le délai de livraison pour la ligne de commande i que l'on ajoute dans le tableau
                    delaiLivraison=objet.calculDelai(panier.get(i).getNbrExemplaires());
                }
            }
        }
        dateLivraison=dateEmission.plusDays(delaiLivraison);    // Créer la date de livrison en ajoutant à la date actuelle le délai de livraison

        
        System.out.println("Veuillez renseigner votre adresse email :\n");
        System.out.print("--> email : ");
        email=sc.nextLine();
        Commande commande = new Commande(genererNumeroCommande(),email,dateEmission,dateLivraison,panier);
        this.commandes.add(commande);
        sortCommande();
        this.nbrCommandes+=1;
    }

    public String genererReference(String equipement) {
        String ref;
        String ref2 = "";
        int cpt = 0;
        String nombre;
        

        ref=equipement;
        
        for (int i = 0; i < this.equipements.size(); i++) {      //Boucle afin de compter le nombre d'équipement possédant les mêmes lettres dans la référence souhaitée 
            ref2 = "" + this.equipements.get(i).getReference().charAt(0) + this.equipements.get(i).getReference().charAt(1);
            if (ref.equalsIgnoreCase(ref2)) {     ///Vérifie que les éléments ont le même type d'équipement grâce au deux premières lettres sans prendre en compte les majuscules
                cpt += 1; //Ajoute 1 au compteur cpt afin de connaître le nombre d'équipements du même type que celui qu'on souhaite ajouter
            }
        }

        int[] tab = new int[cpt];   //Intitialisation d'un tableau avec de taille de la variable cpt
        int cpt2 = 0;                 //Intitialisation d'un compteur afin de placer des éléments dans le tableau tab dans les cases cpt2
        if (tab.length != 0) {

            for (int i = 0; i < this.equipements.size(); i++) {      //Boucle for pour intitlasier le tableau tab en récupérant les trois nombres des références de chacun des Equipements 
                ref2 = "" + this.equipements.get(i).getReference().charAt(0) + this.equipements.get(i).getReference().charAt(1);
                if (ref.equalsIgnoreCase(ref2)) {     ///Vérifie que les éléments ont le même type d'équipement grâce au deux premières lettres sans prendre en compte les majuscules
                    nombre = "" + getNumeric(i, 2) + getNumeric(i, 3) + getNumeric(i, 4);   //Variable nombre afin de concatener les nombres des références
                    tab[cpt2] = Integer.parseInt(nombre);
                    cpt2 += 1;
                }
            }

            for (int i = 1; i <= tab.length; i++) {       //Utilisation du tri à bulle afin de trier par ordre croissant tous les numéros de références
                for (int j = 0; j <= (tab.length - 1 - i); j++) {
                    if (tab[j + 1] < tab[j]) {
                        cpt = tab[j + 1];
                        tab[j + 1] = tab[j];
                        tab[j] = cpt;
                    }
                }
            }

            if (tab[tab.length - 1] <= 9) {   //Si le numéro de référence contient seulement un chiffre alors on rajoute deux zéros suivis du chiffre (car la réf. doit avoir 5 caractères)
                ref += "00" + (tab[tab.length - 1] + 1);
                return ref;
            } else if (tab[tab.length - 1] <= 99) {    //Si le numéro de référence contient deux chiffres, alors on rajoute un zéro suivis desdeux chiffres 
                ref += "0" + (tab[tab.length - 1] + 1);
                return ref;
            } else {          //Si le numéro de référence contient trois chiffres alors pas besoins de rajouter des zéros, on ajoute directement les trois chiffres
                ref += "" + (tab[tab.length - 1] + 1);
                return ref;
            }

        } else {      //Le tableau ne contient aucun éléments, on peut donc rajouter la première référence en fonction du type d'équipement choisis
            if (equipement.equals("JO")) {
                return "JO000";
            } else if (equipement.equals("PR")) {
                return "PR000";
            } else {
                return "TR000";
            }
        }

    }

    
    public String genererNumeroCommande(){
        String numero="";
        LocalDate dateCourante = LocalDate.now();
        numero += dateCourante.getYear();
        if(dateCourante.getYear()!=this.annee){
            this.cptCommande=0;
        }
        String cpt =""+this.cptCommande;
        this.cptCommande+=1;
        switch(cpt.length()){
            case 1:
                numero+="000"+cpt;
                return numero;
            case 2:
                numero+="00"+cpt;
                return numero;
            case 3:
                numero+="0"+cpt;
                return numero;
            default :
                numero+=cpt;
                return numero;
        }
        
    }
    
    public int getNumeric(int index1, int index2) {      //Convertie le caractère char d'une référence du tableau equipement en int
        int nombre = Character.getNumericValue(this.equipements.get(index1).getReference().charAt(index2));
        return nombre;
    }

    public void sortEquipement() {
        Equipement change;

        //Tri par nom
        for (int i = 1; i <= this.equipements.size(); i++) {       //Utilisation du tri à bulle afin de trier par ordre croissant tous les numéros de références
            for (int j = 0; j <= (this.equipements.size() - 1 - i); j++) {
                if (this.equipements.get(j).placeApres(this.equipements.get(j+1))) {
                    change = this.equipements.get(j + 1);
                    this.equipements.set((j + 1), this.equipements.get(j));
                    this.equipements.set((j), change);
                }
            }
        }

 
    }
    
    
    public void sortCommande() {
        Commande change;
        //Tri par email et numéro de commande
        for (int i = 1; i <= this.commandes.size(); i++) {
            for(int j=0;j <= (this.commandes.size() - 1 - i); j++){
                if (this.commandes.get(j).placeApres(this.commandes.get(j + 1))) {
                    change = this.commandes.get(j + 1);
                    this.commandes.set((j + 1), this.commandes.get(j));
                    this.commandes.set((j), change);
                }
            }
        }
    }

    public Equipement recherche(String reference) {
        for (int i = 0; i < this.equipements.size(); i++) {  //Boucle for pour parcourir le tableau
            if (this.equipements.get(i).getReference().equals(reference)) {    //Condition afin de vérifier si la référence des objets du tableau correspondent à celui voulu
                return this.equipements.get(i);
            }
        }

        return null;
    }
    
    public void affichage(String type) {
        String ref;
        if (type.equals("Joueurs")) {
            ref = "JO";
        } else if (type.equals("Terrain")) {
            ref = "TR";
        } else {
            ref = "PR";
        }
        for (int i = 0; i < this.equipements.size(); i++) {  //Boucle for pour parcourir le tableau
            if (this.equipements.get(i).getReference().substring(0, 2).equalsIgnoreCase(ref)) { //Condition afin de regarder la correspondance entre les deux premières lettres de la référence des objets du tableau avec le type voulu
                System.out.println(this.equipements.get(i).toString());  //Affichage des equipements qui ont le même type que celui souhaité
            }
        }
    }

    public List<LigneCommande> choixEquip() {
        Scanner sc = new Scanner(System.in);      //Initialisation d'un scanner et des variables
        String indicRef;
        String indicNbr;
        String continue_achat;
        List<Equipement> indicEquip = new ArrayList<>();
        List<LigneCommande> panier = new ArrayList<>();
        boolean arret = false;
        
        while(true){
            indicEquip = new ArrayList<>();
            arret=false;
            System.out.println("Indiquer le type d'équipement (JO, PR, TR)et le sport souhaité");
            System.out.print("--> Type d'équipement : ");
            String type = sc.nextLine();
            System.out.print("--> Sport : ");
            String sport = sc.nextLine();

            System.out.println("\n\nVoici les articles correspondant à votre recherche :\n");

            //On utilise pas la fonction "affichage()" dans les lignes qui suivent puisqu'on souhaite ajouter en même temps les equipements dans un tableau.
            for (int i = 0; i < this.equipements.size(); i++) {      //Boucles for afin de parcourir et d'afficher tous les éléments contenant le type d'équipement et le type de sport souhaité
                if (this.equipements.get(i).getReference().substring(0, 2).equalsIgnoreCase(type) && this.equipements.get(i).getSport().equalsIgnoreCase(sport)) {//Conditions souhaitées par la collectivité
                    System.out.println(this.equipements.get(i).toString());      //Affichar de l'equipement
                    indicEquip.add(this.equipements.get(i));     //Ajout de l'equipement au tableau
                }
            }
            if (indicEquip.size() == 0) {
                System.out.println("Aucun article n'a été trouvé");
                arret=true;
            } else {
                System.out.println("\n\nVeuillez choisir la référence de l'article souhaité ainsi que le nombre d'exemplaires voulu :\n");
                while (arret == false) {    //Boucle while afin de vérifier que que les valeurs saisies par l'utilisateurs sont correctes
                    System.out.print("Référence de l'article : ");
                    indicRef = sc.nextLine();     //L'utilisateur saisie la référence
                    System.out.print("Nombre d'articles : ");
                    indicNbr = sc.nextLine();     //L'utilisateur saisie le nombre d'article

                    for (int i = 0; i < indicEquip.size(); i++) {   //Boucle for afin de parcourir et de créer une ligne de commande à conditions que les valeurs renrtrées par l'utilisateur sont correctes
                        if (indicRef.equals(indicEquip.get(i).getReference())) { //Condition qui vérifie que les valeurs rentrées par l'utilisateurs sont correctes
                            LigneCommande achat = new LigneCommande(indicEquip.get(i).getReference(), Integer.parseInt(indicNbr), indicEquip.get(i).getPrix());  //Création d'une ligne de commande
                            panier.add(achat);   //Ajout de la ligne de commande dans le tableau panier
                            Equipement objet = recherche(indicRef);
                            objet.majDispo(-Integer.parseInt(indicNbr));
                            arret = true; //Changement de la variable bouléenne afin de sortir de la boucle while
                            break;      //Sorti de la boucle for
                        }
                    }
                    if (arret == false) {   //Si la variable arret est faux c'est que l'utilisateur a rentré de mauvaises valeures et doit donc les rerentrer
                        System.out.println("\nErreur, veuillez resaisir s'il-vous-plaît\n");
                    }
                }
            }
            
            System.out.println("Que souhaitez-vous faire ? \n");
            System.out.println("--> Continuez les achats (1)");
            System.out.println("--> Finir les achats (2)\n");
            continue_achat=sc.nextLine();
            while(!continue_achat.equals("1") && !continue_achat.equals("2")){
                System.out.println("Erreur, Veuillez saisir 1 ou 2");
                continue_achat=sc.nextLine();
            }
            if(continue_achat.equals("2")){
                System.out.println("Fin des achats");
                return panier;
            }
        }

    }

    public String toString() {

        return "Voici les informations de votre magasin : " + this.nomMagasin + "\n"
                + "\n Nombre d'Equipements : " + this.nbrEquipement
                + "\n Nombres de Commandes : " + nbrCommandes;

    }

    public void versFichierEquipements() throws IOException {
        FileWriter fich = new FileWriter(NOM_FICHIER_EQUIPEMENT);  

        for (int i = 0; i < this.equipements.size(); i++) {     // Boucle for pour parcourir le tableau equipements
            String chaine = this.equipements.get(i).versFichier() + System.lineSeparator();     //Créer une chaîne de caracrère en y inscrivant les différents attributs des équipements
            fich.write(chaine);     //Saisi dans le fichier texte les différents attributs des équipements
        }

        fich.close();   //Ferme le fichier

    }

    public void depuisFichierEquipements() throws FileNotFoundException, IOException {  //IOException : Gère les problèmes de fichiers introuvable, autorisations sinsuffisantes etc...
        FileReader fich = new FileReader(NOM_FICHIER_EQUIPEMENT); // Crée un objet FileWriter pour écrire dans le fichier texte Equipements et gère les exceptions d'entrée/sortie.
        BufferedReader br = new BufferedReader(fich);   //Un BufferedReader offre des méthodes pour lire des données à partir d'un flux de caractères (comme un fichier)
        String ref = br.readLine(); //Le curseur commence automatiquement à la ligne 1 du fichier texte, afin de récupère la référence, puis place le curseur à la ligne 2

        // **** REMARQUE : Les références sont situés sur les lignes impaires (1,3,5,...,2n+1), et les autres atttributs sur les lignes paires (2,4,6,...,2n). Voir un exemple de fichier texte ****
        
        while (ref != null) {   
            String ligne = br.readLine();   //Le curseur, situé à la ligne 2n, va récupérer les valeurs de cette ligne en les enregistrant dans la chaine de caractère "ligne", puis place le curseur à la ligne (2n+1)
            String[] tab = ligne.split(" : ");  //Sépare la chaine de caractère lorsqu'il y a la valeur " : " et range chacunes des parties (attributs) dans un case du tableau
            Equipement equip;   //On initialise un objet equipement ansi que les attributs de la classe Equipements communs à tous les objets présents dans les 4 premières cases du tableau tab
            String sport = tab[0];
            String nom = tab[1];
            double prix = Double.parseDouble(tab[2]);
            int nbrExemplaires = Integer.valueOf(tab[3]);
            
            if (ref.startsWith("JO")) {     //On vérifie quel type d'equipement c'est en fonction de sa référence afin de récupérer les derniers attributs pour créer cet equipement
                String taille = tab[4];
                String coloris = tab[5];

                equip = new Joueurs(ref, sport, nom, prix, nbrExemplaires, taille, coloris);

            } else if (ref.startsWith("PR")) {
                String taille = tab[4];
                String coloris = tab[5];
                String niveau = tab[6];

                equip = new ProtectionJoueurs(ref, sport, nom, prix, nbrExemplaires, taille, coloris, niveau);

            } else {
                double poids = Double.parseDouble(tab[4]);
                double hauteur = Double.parseDouble(tab[5]);
                double largeur = Double.parseDouble(tab[6]);

                equip = new Terrain(ref, sport, nom, prix, nbrExemplaires, poids, hauteur, largeur);
            }
            this.equipements.add(equip);    //On ajoute l'equipement dans le tableau equipements
            sortEquipement();   //Tri du taleau
            this.nbrEquipement += 1;    // On ajoute (+1) au compteur d'equipements
            ref = br.readLine();    // Le curseur situé à la ligne (2n+1) va récupérer la référence de la ligne puis il va se placer à la ligne 2n

        }
        fich.close();   //A la fin on ferme le fichier
    }
    
    
     public void versFichierCommandes() throws IOException {
        FileWriter fich = new FileWriter(NOM_FICHIER_COMMANDE);  

        for (int i = 0; i < this.commandes.size(); i++) {     // Boucle for pour parcourir le tableau equipements
            String chaine = this.commandes.get(i).versFichier() + System.lineSeparator()+this.commandes.get(i).getNbrArticles()+System.lineSeparator();     //Créer une chaîne de caracrère en y inscrivant les différents attributs des équipements
            for(int j=0;j<this.commandes.get(i).getNbrArticles();j++){
                chaine+=this.commandes.get(i).getLigneCommande(j).versFichier();
            }
            fich.write(chaine);     //Saisi dans le fichier texte les différents attributs des équipements
        }

        fich.close();   //Ferme le fichier

    }
     
     public void depuisFichierCommandes() throws FileNotFoundException, IOException {  //IOException : Gère les problèmes de fichiers introuvable, autorisations sinsuffisantes etc...
        FileReader fich = new FileReader(NOM_FICHIER_COMMANDE); // Crée un objet FileWriter pour écrire dans le fichier texte Equipements et gère les exceptions d'entrée/sortie.
        BufferedReader br = new BufferedReader(fich);   //Un BufferedReader offre des méthodes pour lire des données à partir d'un flux de caractères (comme un fichier)
        String numero = br.readLine(); //Le curseur commence automatiquement à la ligne 1 du fichier texte, afin de récupère le numéro de la commande, puis place le curseur à la ligne 2

        
        while (numero != null) {   
            String ligne = br.readLine();   //Le curseur, situé à la ligne 2n, va récupérer les valeurs de cette ligne en les enregistrant dans la chaine de caractère "ligne", puis place le curseur à la ligne (2n+1)
            String[] tab = ligne.split(" : ");  //Sépare la chaine de caractère lorsqu'il y a la valeur " : " et range chacunes des parties (attributs) dans un case du tableau
            List<LigneCommande> listeCommandes=new ArrayList<>();   //On initialise un tableau dynamique (pour chaque commande) de LigneCommande afin de renseigner tous les articles d'une commande dedans
            String email = tab[0];
            LocalDate dateEmission = LocalDate.parse(tab[1]);
            LocalDate dateLivraison = LocalDate.parse(tab[2]);
            String prixTot = tab[3];
            int nbrArticles = Integer.parseInt(br.readLine());  // Lit la ligne comportant le nombre d'articles de la commande 
            for(int i=0;i<nbrArticles;i++){     // Boucle afin de créer et d'ajouter les objets LigneCommande
                ligne = br.readLine();  // Récupère les valeurs de l'article 
                tab = ligne.split(" : ");   //Sépare la chaine de caractère lorsqu'il y a la valeur " : " et range chacunes des parties (attributs) dans un case du tableau 
                String ref=tab[0];  // Récupération des attributs dans des variables à partir du tableau
                int nbrExemplaires = Integer.parseInt(tab[1]);
                double prixUnit = Double.parseDouble(tab[2]);
                LigneCommande article = new LigneCommande(ref,nbrExemplaires,prixUnit); // Création d'un objet LigneCommande
                listeCommandes.add(article);    // Rajout de l'objet au sein du tableau dynamique listeCommandes
            }
            Commande commande = new Commande(numero,email,dateEmission,dateLivraison,listeCommandes);   // Création de l'objet Commande
            this.commandes.add(commande);   // On ajoute l'objet commande dans le tableau commandes
            sortCommande();
            this.nbrCommandes+=1;   // On ajoute (+1) au compteur de commandes
            this.cptCommande+=1;
            
            numero = br.readLine();    // Le curseur situé à la ligne (2n+1) va récupérer la référence de la ligne puis il va se placer à la ligne 2n

        }
        fich.close();   //A la fin on ferme le fichier
    }
}



