package tp3ventes;

public class LigneCommande {

    private String referenceCommande;
    private int nbrExemplaires;
    private double prix;

    LigneCommande(String reference, int nbrExemplaires, double prix) {

        this.referenceCommande = reference ;
        this.nbrExemplaires = nbrExemplaires ;
        this.prix = prix ;
        
    }
    
    public String toString() {
        
        return referenceCommande + ", " + nbrExemplaires + ", " + prix ; 
        
    }
    
    public double getPrix(){
        return this.prix;
    }
    
    public String getReferenceCommande(){
        return this.referenceCommande;
    }
    
    public int getNbrExemplaires(){
            return this.nbrExemplaires;
        }
    
    public String versFichier(){
            return referenceCommande + " : "+nbrExemplaires+" : "+prix+ System.lineSeparator();  /* Retourne une chaine de caractère contenant la référence, un retour à la ligne,
                                                                                                                        puis les attributs de la classe mère tous séparés par " : "  */
        }
}
