package tp3ventes;

import java.time.LocalDate;

public class Commande {

    private int numero ;
    private String email ;
    private LocalDate date ;
    private int total ;
    private int[][] tableau ;


    Commande(int numero, String email, LocalDate date, int total, int [][] tableau) {
        
        this.numero = numero ;
        this.email = email ;
        this.date = date ;
        this.total = total ;
        this.tableau = tableau ;
        
    }
    
    public String toString() {
        
        return numero + ", " + email + ", " + date + ", " + total + ", " + tableau ; 
        
    }

}



