/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp3ventes;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author quent
 */
public class TP3Ventes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
                List<Equipement> equipement=new ArrayList<>();
                List<LigneCommande> commande=new ArrayList<>();
                Joueurs ekip = new Joueurs("JO000","Baseball","maillot",123,30,"L","Black");
                equipement.add(ekip);
                Equipement ekip1 = new Equipement("EQ002","Football","protege-tibias",123,30);
                equipement.add(ekip1);
                Joueurs ekip2 = new Joueurs("JO001","Football","Short",123,30,"M","White");
                equipement.add(ekip2);
                
                Magasin magasin = new Magasin(equipement,commande);
                magasin.ajout("Football","t-shirt",123,30);
                magasin.choixEquip("Equipement","Football");
                for(int i=0;i<magasin.commande.size();i++){
                    System.out.println(magasin.commande.get(i));
                }
                
                

	}
    
}
