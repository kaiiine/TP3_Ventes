/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp3ventes;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author quent
 */
public class Magasin {
    private final String nomMagasin="Milieu Sport ou le Rinté";
    private int nbrEquipement;
    private List<Equipement> equipement;
    private int nbrCommandes;
    public List<LigneCommande> commande;
    
    public Magasin(List<Equipement> tab_equipement, List<LigneCommande> tab_commande){
        this.equipement = new ArrayList<>();    //Initialisation du tableau dynamique equipement
        this.commande = new ArrayList<>();      //Initialisation du tableau dynamique commande
        
        for(int i=0;i<tab_equipement.size();i++){   //Insère les objets Equipement déjà présent dans le tableau "tab_equipement" dans l'attribut equipement
            this.equipement.add(tab_equipement.get(i));
        }
        this.nbrEquipement=this.equipement.size();      //Initialise le nombre d'objets Equipement 
        
        for(int i=0;i<tab_commande.size();i++){     //Insère les objets LigneCommande déjà présent dans le tableau "tab_commande" dans l'attribut commande
            this.commande.add(tab_commande.get(i));
        }
        this.nbrCommandes=this.commande.size();         //Initialise le nombre d'objets LigneCommande
    }
    
    
    public void afficherEquipement(){
        for(int i=0;i<equipement.size();i++) {
			System.out.println(equipement.get(i).getReference());
		}
    }
    
    
    public Equipement ajout(String sport, String designation, double prix, int nbrExemplaires){    //Méthode permettant de créer et de retourner un objet Equipement
        Equipement equipement = new Equipement(this.genererReference("Equipement"),sport,designation,prix,nbrExemplaires);
        this.equipement.add(equipement);
        sortEquipement();
        this.nbrEquipement+=1;
        return equipement;
    }
    
    public Terrain ajout(String sport, String designation, double prix, int nbrExemplaires, double poids, double hauteur, double largeur){    //Méthode permettant de créer et de retourner un objet Terrain
        Terrain terrain = new Terrain(this.genererReference("Terrain"),sport,designation,prix,nbrExemplaires,poids,hauteur,largeur);
        this.equipement.add(terrain);
        sortEquipement();
        this.nbrEquipement+=1;
        return terrain;
    }
    public Joueurs ajout(String sport, String designation, double prix, int nbrExemplaires, String taille, String coloris){   //Méthode permettant de créer et de retourner un objet Joueurs
        Joueurs joueur = new Joueurs(genererReference("Joueurs"),sport,designation,prix,nbrExemplaires,taille,coloris);
        this.equipement.add(joueur);
        sortEquipement();
        this.nbrEquipement+=1;
        return joueur;
    }
    public ProtectionJoueurs ajout(String sport, String designation, double prix, int nbrExemplaires, String taille, String coloris,String niveau){ //Méthode permettant de créer et de retourner un objet ProtectionJoueurs
        ProtectionJoueurs protection = new ProtectionJoueurs(this.genererReference("ProtectionJoueurs"), sport,designation,prix,nbrExemplaires,taille,coloris,niveau);
        this.equipement.add(protection);
        sortEquipement();
        this.nbrEquipement+=1;
        return protection;
    }
    
    
    
    public String genererReference(String equipement){
        String type_equipement;
        String ref;
        String ref2="";
        int cpt=0;
        String nombre;
        
        
        type_equipement=equipement.substring(0,2);   //Récupère les deux premières lettres du type d'equipement souhaité
        type_equipement=type_equipement.toUpperCase();      //Met en majuscule les deux premières lettres du type d'équipement
        if(type_equipement.equals("TE")){   //Nous souhaitons obtenir les lettres TR pour la référence d'un équipement de terrain et non TE.
            ref="TR"; 
        }else{
            ref=""+type_equipement;
        }
        
        
        for(int i=0;i<this.equipement.size();i++){      //Boucle afin de compter le nombre d'équipement possédant les mêmes lettres dans la référence souhaitée 
            ref2=""+this.equipement.get(i).getReference().charAt(0)+this.equipement.get(i).getReference().charAt(1);
            if(ref2.equalsIgnoreCase("TE")){    //Si l'equipement est de type terrain, nous remplaçons les premières lettres TE par TR comme demandée dans l'exercice pour la référence
                ref2="TR";
            }
            if(ref.equalsIgnoreCase(ref2)){     ///Vérifie que les éléments ont le même type d'équipement grâce au deux premières lettres sans prendre en compte les majuscules
                cpt+=1; //Ajoute 1 au compteur cpt afin de connaître le nombre d'équipements du même type que celui qu'on souhaite ajouter
            }
        }
        
        int[] tab = new int[cpt];   //Intitialisation d'un tableau avec de taille de la variable cpt
        int cpt2=0;                 //Intitialisation d'un compteur afin de placer des éléments dans le tableau tab dans les cases cpt2
        if(tab.length!=0){
            
            for(int i=0;i<this.equipement.size();i++){      //Boucle for pour intitlasier le tableau tab en récupérant les trois nombres des références de chacun des Equipements 
                ref2=""+this.equipement.get(i).getReference().charAt(0)+this.equipement.get(i).getReference().charAt(1);
                if(ref2.equalsIgnoreCase("TE")){    //Si l'equipement est de type terrain, nous remplaçons les premières lettres TE par TR comme demandée dans l'exercice pour la référence
                    ref2="TR";
                }
                if(ref.equalsIgnoreCase(ref2)){     ///Vérifie que les éléments ont le même type d'équipement grâce au deux premières lettres sans prendre en compte les majuscules
                    nombre=""+getNumeric(i,2)+getNumeric(i,3)+getNumeric(i,4);   //Variable nombre afin de concatener les nombres des références
                    tab[cpt2]=Integer.parseInt(nombre);
                    cpt2+=1;
                }
            }

            for (int i=1;i<=tab.length;i++) {       //Utilisation du tri à bulle afin de trier par ordre croissant tous les numéros de références
                for (int j=0; j<=(tab.length-1-i);j++) {
                        if(tab[j+1]<tab[j]) {
                                cpt=tab[j+1];
                                tab[j+1]=tab[j];
                                tab[j]=cpt;
                        }
                }
            }
            
            if(tab[tab.length-1]<=9){   //Si le numéro de référence contient seulement un chiffre alors on rajoute deux zéros suivis du chiffre (car la réf. doit avoir 5 caractères)
                ref+="00"+(tab[tab.length-1]+1);
                return ref;
            }else if(tab[tab.length-1]<=99){    //Si le numéro de référence contient deux chiffres, alors on rajoute un zéro suivis desdeux chiffres 
                ref+="0"+(tab[tab.length-1]+1);
                return ref;
            }else{          //Si le numéro de référence contient trois chiffres alors pas besoins de rajouter des zéros, on ajoute directement les trois chiffres
                ref+=""+(tab[tab.length-1]+1);
                return ref;
            }
    
        }else{      //Le tableau ne contient aucun éléments, on peut donc rajouter la première référence en fonction du type d'équipement choisis
            if(equipement.equals("Joueurs")){
                return "JO000";
            }else if(equipement.equals("ProtectionJoueurs")){
                return "PR000";
            }else{
                return "TR000";
            }
        }
        
    }
    
    public int getNumeric(int index1, int index2){      //Convertie le caractère char d'une référence du tableau equipement en int
        int nombre = Character.getNumericValue(this.equipement.get(index1).getReference().charAt(index2));
        return nombre;
    }
    
    public void sortEquipement(){
        Equipement change;
        
        //Tri par nom
        for (int i=1;i<=this.equipement.size();i++) {       //Utilisation du tri à bulle afin de trier par ordre croissant tous les numéros de références
            for (int j=0; j<=(this.equipement.size()-1-i);j++) {
                    if(Character.getNumericValue(this.equipement.get(j+1).getReference().charAt(0))<Character.getNumericValue(this.equipement.get(j).getReference().charAt(0))) {
                            change=this.equipement.get(j+1);
                             this.equipement.set((j+1), this.equipement.get(j));
                            this.equipement.set((j), change);
                    }
            }
        }
        
        //Tri par numéros
        for(int i=0;i<this.equipement.size();i++){
            if(i>0 && !this.equipement.get(i).placeApres(this.equipement.get(i-1))){
                change=this.equipement.get(i-1);
                this.equipement.set((i-1), this.equipement.get(i));
                this.equipement.set((i), change);
            }
        }
    }

    public Equipement recherche(String reference){
        for(int i=0;i<this.equipement.size();i++){
            if(this.equipement.get(i).getReference().equals(reference)){
                return this.equipement.get(i);
            }
        }
        
        return null;
    }

    public void affichage(String  type, String sport){
        for(int i=0;i<this.equipement.size();i++){
            if(this.equipement.get(i).getReference().substring(0,2).equalsIgnoreCase(type.substring(0,2)) && this.equipement.get(i).getSport().equals(sport)){
                this.equipement.get(i).toString();
            }
        }
    }

    
    public void choixEquip(String type, String sport){
        Scanner sc=new Scanner(System.in);      //Initialisation d'un scanner et des variables
        String indicRef;
        String indicNbr;
         List<Equipement> indicEquip=new ArrayList<>();
         boolean arret=false;
        System.out.println("Voici les articles correspondant à votre recherche :\n");
        
        //On utilise pas la fonction "affichage()" dans les lignes qui suivent puisqu'on souhaite ajouter en même temps les equipements dans un tableau.
        
        for(int i=0;i<this.equipement.size();i++){      //Boucles for afin de parcourir et d'afficher tous les éléments contenant le type d'équipement et le type de sport souhaité
            if(this.equipement.get(i).getReference().substring(0,2).equalsIgnoreCase(type.substring(0,2)) && this.equipement.get(i).getSport().equals(sport)){//Conditions souhaitées par la collectivité
                System.out.println(this.equipement.get(i).toString());      //Affichar de l'equipement
                indicEquip.add(this.equipement.get(i));     //Ajout de l'equipement au tableau
            }
        }
        System.out.println("\n\nVeuillez choisir la référence de l'article souhaité ainsi que le nombre d'exemplaires voulu :\n");
        while(arret==false){    //Boucle while afin de vérifier que que les valeurs saisies par l'utilisateurs sont correctes
            System.out.print("Référence de l'article : ");  
            indicRef=sc.nextLine();     //L'utilisateur saisie la référence
            System.out.print("Nombre d'articles : ");
            indicNbr=sc.nextLine();     //L'utilisateur saisie le nombre d'article
            
            for(int i=0;i<indicEquip.size();i++){   //Boucle for afin de parcourir et de créer une ligne de commande à conditions que les valeurs renrtrées par l'utilisateur sont correctes
                if(indicRef.equals(indicEquip.get(i).getReference()) && Integer.parseInt(indicNbr)<=indicEquip.get(i).getNbrExemplaires()){ //Condition qui vérifie que les valeurs rentrées par l'utilisateurs sont correctes
                    LigneCommande achat=new LigneCommande(indicEquip.get(i).getReference(),Integer.parseInt(indicNbr),indicEquip.get(i).getPrix());  //Création d'une ligne de commande
                    this.commande.add(achat);   //Ajout de la ligne de commande dans l'attribut "commande"
                    arret=true; //Changement de la variable bouléenne afin de sortir de la boucle while
                    break;      //Sorti de la boucle for
                }
            }
            if(arret==false){   //Si la variable arret est faux c'est que l'utilisateur a rentré de mauvaises valeures et doit donc les rerentrer
                System.out.println("\nErreur, veuillez resaisir s'il-vous-plaît\n");
            }
        }
        
    }
    
    
    
    public String toString() {
        
        return "Voici les informations de votre magasin : "+this.nomMagasin+"\n"+
                "\n Nombre d'Equipements : "+this.nbrEquipement+
                "\n Nombres de Commandes : "+nbrCommandes;
        
    }
    
    

}