package tp3ventes;

public class Terrain extends Equipement{

	private double poids;
	private double hauteur;
	private double largeur;
	
	public Terrain(String ref, String sport, String designation, double prix, int nbrExemplaires, double poids, double hauteur, double largeur) {
		super(ref,sport,designation, prix, nbrExemplaires);     // Initialise les attributs de la classe Equipement
                this.poids=poids;                                       //Initialisation des attributs de la classe Terrain
                this.hauteur=hauteur;
                this.largeur=largeur;
	}
        
        public Terrain(String ref, String sport, String designation, double prix, int nbrExemplaires){
            super(ref,sport,designation, prix, nbrExemplaires);
        }
        
        public String toString() {
        
        return super.toString()+
                "\nPoids : "+this.poids+
                "\n Hauteur : "+this.hauteur+
                "\nLargeur : "+this.largeur; 
        
    }
	
}
