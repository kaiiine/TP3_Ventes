/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp3ventes;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author quent
 */
public class TP3Ventes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
                List<Equipement> equipements=new ArrayList<>();
                //List<LigneCommande> commandes=new ArrayList<>();
                
                
                Magasin magasin = new Magasin(equipements);
                magasin.depuisFichierEquipements();
                magasin.depuisFichierCommandes();
                //magasin.afficherCommande();
                
                /*
                magasin.ajout("Basketball","ballon",34,143,3,24.8,24.8);
                magasin.ajout("Football","protege-tibias",123,30,"M","Black","expert");
                magasin.ajout("Football","Short",123,30,"S","White");
                magasin.ajout("Football","Short",123,30,"M","White");
                magasin.ajout("Football","t-shirt",123,30,"XL","White");
                */
                
                
                /*
                magasin.ajout("Tennis","Raquette",123,246,3,71,38);
                int delaiLivraison = equipements.get(equipements.size()-1).calculDelai(3);

                System.out.println("Le délai de livraison du produit est de : " + delaiLivraison + " jours./n Merci pour votre commande");
                */
               
                
                //magasin.ajout("Golf","Putter",200,34,4);
                //magasin.ajout("Golf","Driver",200,34,4);
                //magasin.ajout("Golf","Fers 1",133,78,3.6);
                
                List<LigneCommande> panier = magasin.choixEquip();
                magasin.ajout(panier);
                magasin.afficherCommande();
                magasin.versFichierCommandes();
                
                //magasin.afficherEquipement();
                //magasin.versFichierEquipements();
	}
    
}
