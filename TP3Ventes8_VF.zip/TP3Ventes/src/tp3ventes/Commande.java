package tp3ventes;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Commande {

    private String numero ;
    private String email ;
    private LocalDate dateEmission ;
    private LocalDate dateLivraison ;
    private double total ;
    List<LigneCommande> listeCommandes = new ArrayList<>();


    Commande(String numero, String email, LocalDate dateEmission, LocalDate dateLivraison,List<LigneCommande> tableau) {
        
        
        this.numero = numero ;
        this.email = email ;
        this.dateEmission = dateEmission ;
        this.dateLivraison=dateLivraison;
        this.total =0 ;
        
        for(int i=0;i<tableau.size();i++){
            listeCommandes.add(tableau.get(i));
            total+=tableau.get(i).getPrix()*tableau.get(i).getNbrExemplaires();
        }
        
    }
    
    public String toString() {
        
        return numero + ", " + email + ", " + dateEmission + ", " + total + ", " + listeCommandes ; 
        
    }
    
    public LigneCommande getLigneCommande(int i){
        return this.listeCommandes.get(i);
    }
    
    public double getTotal(){
        return this.total;
    }
    
    public int getNbrArticles(){
        return listeCommandes.size();
    }
    
    public String versFichier(){
            return numero + System.lineSeparator()+email+" : "+dateEmission+" : "+dateLivraison+" : "+total;  /* Retourne une chaine de caractère contenant la référence, un retour à la ligne,
                                                                                                                        puis les attributs de la classe mère tous séparés par " : "  */
        }

}



