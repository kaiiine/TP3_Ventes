    package tp3ventes;

public abstract class Equipement {

	private String reference;
	private String sport;
	private String designation;
	private double prix;
	private int nbrExemplaires;
	
	public Equipement(String ref, String sport, String designation, double prix, int nbrExemplaires) {
            
            this.reference=ref;
            this.sport=sport;
            this.designation=designation;
            this.prix=prix;
            this.nbrExemplaires=nbrExemplaires;
            
            //double poids = getPoids();
	}
	
	public String toString() {
            return "\nVoici les informations de votre objet : "+this.designation+"\n"+
                    "\nReference : "+this.reference+
                    "\nSport : "+this.sport+
                    "\nDesignation : "+this.designation+
                    "\nPrix : "+this.prix+
                    "\nNombre d'exemplaires : "+this.nbrExemplaires;
	}
        
        public boolean placeApres(Equipement objet) {
            boolean change =false;
            for(int i=0; i<this.reference.length();i++){
                if(this.reference.charAt(i)>objet.reference.charAt(i)){
                    change=true;
                    break;
                }
                
            }
            if(change==true){
                    return true;
                }else{
                    return false;
                }
           
        }
        
        public String getReference(){
            return this.reference;
        }
        
        public String getSport(){
            return this.sport;
        }
        
        public int getNbrExemplaires(){
            return this.nbrExemplaires;
        }
        
        public void setNbrExemplaires(){
            this.nbrExemplaires+=1;
        }
        
        public double getPrix(){
            return this.prix;
        }
        
        public String getDesignation(){
            return this.designation;
        }
        
        public abstract String getTaille();
        public abstract String getColoris();
        public abstract String getNiveau();
        public abstract double getPoids();
        public abstract double getHauteur();
        public abstract double getLargeur();
        
        public String versFichier(){
            return getReference() + System.lineSeparator()+sport+" : "+designation+" : "+prix+" : "+nbrExemplaires;  /* Retourne une chaine de caractère contenant la référence, un retour à la ligne,
                                                                                                                        puis les attributs de la classe mère tous séparés par " : "  */
        }
        
        
        public void majDispo(int x) {
            nbrExemplaires += x ;            
        }
       
        public boolean verifDispo (int x) {
            return nbrExemplaires > x ;     //Retourne true si le nombre d'exemplaires en stock dans le magasin est supérieur à la quantité demandé et false sinon
        }

        
        public int calculDelai(int nombre) {
            int delaiMax ;
            String name = this.getClass().getSimpleName();

            switch(name){

                case "Terrain":
                    if (this.getPoids()*nombre > 100) {
                    delaiMax = 5 ;
                    }
                    else {
                        delaiMax = 3 ;
                    }
                    if (this.nbrExemplaires <= 0) {
                        delaiMax += 30 ;
                    }
                    return delaiMax;

                default :
                    delaiMax=3;
                    if (this.nbrExemplaires <= 0) {
                        delaiMax += 30 ;
                    }
                    return delaiMax;
            }

        }
        
}
