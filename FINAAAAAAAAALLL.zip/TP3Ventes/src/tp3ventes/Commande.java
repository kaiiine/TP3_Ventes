package tp3ventes;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Commande {

    private String numero ;
    private String email ;
    private LocalDate dateEmission ;
    private LocalDate dateLivraison ;
    private double total ;
    List<LigneCommande> listeCommandes = new ArrayList<>();


    Commande(String numero, String email, LocalDate dateEmission, LocalDate dateLivraison,List<LigneCommande> tableau) {
        
        
        this.numero = numero ;
        this.email = email ;
        this.dateEmission = dateEmission ;
        this.dateLivraison=dateLivraison;
        this.total =0 ;
        
        for(int i=0;i<tableau.size();i++){
            listeCommandes.add(tableau.get(i));
            total+=tableau.get(i).getPrix()*tableau.get(i).getNbrExemplaires();
        }
        
    }
    
    public String toString() {
        
        return numero + ", " + email + ", " + dateEmission + ", " + total + ", " + listeCommandes ; 
        
    }
    
    public LigneCommande getLigneCommande(int i){
        return this.listeCommandes.get(i);
    }
    
    public double getTotal(){
        return this.total;
    }
    
    public int getNbrArticles(){
        return listeCommandes.size();
    }
    
    public String versFichier(){
            return numero + System.lineSeparator()+email+" : "+dateEmission+" : "+dateLivraison+" : "+total;  /* Retourne une chaine de caractère contenant la référence, un retour à la ligne,
                                                                                                                        puis les attributs de la classe mère tous séparés par " : "  */
        }
    
    
    public boolean placeApres(Commande objet) {
        boolean change_mail = false;
        boolean change_num = false;
        String mail=this.email;
        if(objet.email.length()<this.email.length()){   // Regarde le mail le plus petit et le prend comme longueur de référence pour éviter les erreurs dans les boucles for
            mail=objet.email;
        }
        
        if(!this.email.equals(objet.email)){    // Vérifie les deux emails pour trier par ordre lexicographique, dans le cas ou les emails comparés sont différents
            for (int i = 0; i < mail.length(); i++) {
                if (this.email.charAt(i) > objet.email.charAt(i)) {
                    change_mail=true;
                    break;
                }
            }
        }else{  // Vérifie les numéros de commande pour trier par ordre croissant les numéros de commandes, dans le cas où les emails comparés sont les mêmes
            for (int i = 0; i < this.numero.length(); i++) {
                if (this.numero.charAt(i) > objet.numero.charAt(i)) {
                    change_num = true;
                    break;
                }
            }
        }
        
        if(change_mail==true || change_num==true){
            return true;
        }else{
            return false;
        }
    }
    
    


}



