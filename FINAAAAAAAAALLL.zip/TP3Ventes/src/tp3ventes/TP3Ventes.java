/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp3ventes;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author quent
 */
public class TP3Ventes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
                Scanner sc = new Scanner(System.in);
                String answer;
                String answer2;
                String answer3;
                boolean run=true;
                boolean runAdmin=true;
                String sport;
                String designation;
                double prix;
                int nbrExemplaires;
                String taille;
                String coloris;
                String niveau;
                double poids;
                double hauteur;
                double largeur;
                char userType='U';
                int cpt=0;
                
                Magasin magasin = new Magasin();
                magasin.depuisFichierEquipements();
                magasin.depuisFichierCommandes();
                
                System.out.println("--------------------------------------------------");
                System.out.println("Bienvenue ....");
                System.out.println("--------------------------------------------------");
                System.out.println("Souhaitez-vous vous connecter :\n");
                System.out.println("    --> Admin (1)");
                System.out.println("    --> Utilisateur (2)\n");
                answer = sc.nextLine();
                while(run){
                    switch(answer){
                        case "1":
                            System.out.println("\n\nBIENVENUE ADMINISTRATEUR");
                            userType='A';
                            run=false;
                            break;
                        case "2":
                            System.out.println("\n\nBIENVENUE UTILISATEUR");
                            userType='U';
                            run=false;
                            break;
                        default:
                            System.out.println("Erreur, veuillez saisir (1) pour admin ou (2) pour Utilisateur");
                            answer = sc.nextLine();    
                    }
                }
                System.out.println("Que souhaitez-vous faire ?\n");
                while(runAdmin){
                    magasin.versFichierEquipements();
                    magasin.versFichierCommandes();
                    answer="";
                    answer2="";
                    answer3="";
                    cpt=1;
                    System.out.println("    --> Acheter un produit ("+cpt+")");
                    cpt+=1;
                    System.out.println("    --> Rechercher un produit ("+cpt+")");
                    cpt+=1;
                    if(userType=='A'){
                        System.out.println("    --> Ajouter un produit ("+cpt+")");
                        cpt+=1;
                    }
                    System.out.println("    --> Quittez ("+cpt+")");
                    System.out.println(" ");
                    answer = sc.nextLine();
                    switch(answer){
                        case "1":       // Acheter un produit
                            System.out.println("--------------------------------------------------------------------------------------------------");
                            List<LigneCommande> panier;
                            panier = magasin.choixEquip();
                            magasin.ajout(panier);
                            System.out.println("\nVotre commande a bien été effectué\n");
                            System.out.println("--------------------------------------------------------------------------------------------------");
                            break;
                        case "2":       // Rechercher un produit
                            System.out.println("Quel type de produit souhaitez-vous rechercher ?");
                            System.out.println("    --> Joueurs (1)");
                            System.out.println("    --> Protection Joueurs (2)");
                            System.out.println("    --> Terrain (3)\n");
                            while(!answer2.equals("1") && !answer2.equals("2") && !answer2.equals("3")){
                                answer2=sc.nextLine();
                                switch(answer2){
                                    case "1":
                                        System.out.println("--------------------------------------------------------------------------------------------------");
                                        magasin.affichage("JO");
                                        System.out.println("--------------------------------------------------------------------------------------------------");
                                        break;
                                    case "2":
                                        System.out.println("--------------------------------------------------------------------------------------------------");
                                        magasin.affichage("PR");
                                        System.out.println("--------------------------------------------------------------------------------------------------");
                                        break;
                                    case "3":
                                        System.out.println("--------------------------------------------------------------------------------------------------");
                                        magasin.affichage("TR");
                                        System.out.println("--------------------------------------------------------------------------------------------------");
                                        break;
                                    default:
                                        System.out.println("Erreur, veuillez saisir (1) pour un article de type Joueurs, (2) pour un article de type Protection Joueurs, (3) pour un aarticle de type Terrain");
                                        continue;
                                }
                            }
                            break;
                        case "3":       // Ajouter un produit

                            if(userType=='A'){
                                System.out.println("--------------------------------------------------------------------------------------------------");
                                System.out.println("Quel est le type de votre nouvel objet : \n");
                                System.out.println("    --> Joueurs (1)");
                                System.out.println("    --> Protection Joueurs (2)");
                                System.out.println("    --> Terrain (3)\n");
                                while(!answer3.equals("1") && !answer3.equals("2") && !answer3.equals("3")){
                                    answer3=sc.nextLine();
                                    switch(answer3){
                                        case "1":
                                            System.out.println("--------------------------------------------------------------------------------------------------");
                                            System.out.print("Veuillez saisir les champs requis : \n");
                                            System.out.print("Sport : ");
                                            sport=sc.nextLine();
                                            System.out.println("--------------------------------------------------------------------------------------------------");
                                            System.out.print("Désignation : ");
                                            designation = sc.nextLine();
                                            System.out.println("--------------------------------------------------------------------------------------------------");
                                            System.out.print("Prix Unitaire : ");
                                            prix=Double.parseDouble(sc.nextLine());
                                            System.out.println("--------------------------------------------------------------------------------------------------");
                                            System.out.print("Nombres d'Exemplaires : ");
                                            nbrExemplaires = Integer.parseInt(sc.nextLine());
                                            System.out.println("--------------------------------------------------------------------------------------------------");
                                            System.out.print("Taille : ");
                                            taille = sc.nextLine();
                                            System.out.println("--------------------------------------------------------------------------------------------------");
                                            System.out.print("Coloris : ");
                                            coloris = sc.nextLine();
                                            System.out.println("--------------------------------------------------------------------------------------------------");
                                            magasin.ajout(sport,designation,prix,nbrExemplaires,taille,coloris);
                                            System.out.println("\n\nVotre article a bien été ajouté\n\n");
                                            System.out.println("--------------------------------------------------------------------------------------------------");
                                            break;

                                        case "2":
                                            System.out.println("--------------------------------------------------------------------------------------------------");
                                            System.out.print("Veuillez saisir les champs requis : \n");
                                            System.out.print("Sport : ");
                                            sport=sc.nextLine();
                                            System.out.println("--------------------------------------------------------------------------------------------------");
                                            System.out.print("Désignation : ");
                                            designation = sc.nextLine();
                                            System.out.println("--------------------------------------------------------------------------------------------------");
                                            System.out.print("Prix Unitaire : ");
                                            prix=Double.parseDouble(sc.nextLine());
                                            System.out.println("--------------------------------------------------------------------------------------------------");
                                            System.out.print("Nombres d'Exemplaires : ");
                                            nbrExemplaires = Integer.parseInt(sc.nextLine());
                                            System.out.println("--------------------------------------------------------------------------------------------------");
                                            System.out.print("Taille : ");
                                            taille = sc.nextLine();
                                            System.out.println("--------------------------------------------------------------------------------------------------");
                                            System.out.print("Coloris : ");
                                            coloris = sc.nextLine();
                                            System.out.println("--------------------------------------------------------------------------------------------------");
                                            System.out.print("Niveau : ");
                                            niveau = sc.nextLine();
                                            System.out.println("--------------------------------------------------------------------------------------------------");
                                            magasin.ajout(sport,designation,prix,nbrExemplaires,taille,coloris,niveau);
                                            System.out.println("\n\nVotre article a bien été ajouté\n\n");
                                            System.out.println("--------------------------------------------------------------------------------------------------");
                                            break;

                                        case "3":
                                            System.out.println("--------------------------------------------------------------------------------------------------");
                                            System.out.print("Veuillez saisir les champs requis (si votre objet ne possède pas de hauteur ni de largeur, renseigner 0) : \n");
                                            System.out.print("Sport : ");
                                            sport=sc.nextLine();
                                            System.out.println("--------------------------------------------------------------------------------------------------");
                                            System.out.print("Désignation : ");
                                            designation = sc.nextLine();
                                            System.out.println("--------------------------------------------------------------------------------------------------");
                                            System.out.print("Prix Unitaire : ");
                                            prix=Double.parseDouble(sc.nextLine());
                                            System.out.println("--------------------------------------------------------------------------------------------------");
                                            System.out.print("Nombres d'Exemplaires : ");
                                            nbrExemplaires = Integer.parseInt(sc.nextLine());
                                            System.out.println("--------------------------------------------------------------------------------------------------");
                                            System.out.print("Poids : ");
                                            poids = Double.parseDouble(sc.nextLine());
                                            System.out.println("--------------------------------------------------------------------------------------------------");
                                            System.out.print("Hauteur : ");
                                            hauteur = Double.parseDouble(sc.nextLine());
                                            System.out.println("--------------------------------------------------------------------------------------------------");
                                            System.out.print("Largeur : ");
                                            largeur = Double.parseDouble(sc.nextLine());
                                            System.out.println("--------------------------------------------------------------------------------------------------");
                                            if(hauteur==0 && largeur==0){
                                                magasin.ajout(sport,designation,prix,nbrExemplaires,poids);
                                            }else{
                                             magasin.ajout(sport,designation,prix,nbrExemplaires,poids,hauteur,largeur);   
                                            }

                                            System.out.println("\n\nVotre article a bien été ajouté\n\n");
                                            System.out.println("--------------------------------------------------------------------------------------------------");
                                            break;

                                        default :
                                            System.out.println("Erreur, veuillez resaisir");
                                            continue;

                                    }
                                }
                            }else{
                                System.out.println("\n\nMerci Beaucoup de votre visite, au-revoir !\n\n");
                                runAdmin=false;
                                continue;
                            }
                            break;

                        case "4":       // Ravitailler un Produit
                            if(userType=='A'){ 
                                System.out.println("\n\nMerci Beaucoup de votre visite, au-revoir !\n\n");
                                runAdmin=false;
                                continue;
                            }else{
                                System.out.println("Erreur, veuillez resaisir");
                                continue;
                            }

                        default :
                            System.out.println("Erreur, veuillez resaisir");
                            continue;
                    }

                    System.out.println("\nSouhaitez-vous effectuer une autre action ?\n");
            }

                
                
                magasin.versFichierEquipements();
                magasin.versFichierCommandes();
	}
    
}
